import 'package:flutter/material.dart';

class ColorConstant {
  static Color primary = const Color(0xFF16425B);
}